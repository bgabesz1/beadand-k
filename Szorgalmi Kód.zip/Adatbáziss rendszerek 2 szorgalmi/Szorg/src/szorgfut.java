public class szorgfut {
	static Szorg1 SZO = new Szorg1();
	static szosca sz = new szosca();

	public static void main(String[] args) {
		SZO.Reg(); 
		SZO.Connect();
		SZO.ReadAllData();
		
		String kod = sz.ReadData("k�rem a term�k k�dj�t: ");
		String termek = sz.ReadData("K�rem a term�k nev�t: ");
		String panasz = sz.ReadData("K�rem a panaszt: ");
		
		SZO.Insert(kod, termek, panasz);
		SZO.Change();
		SZO.Delete();
		SZO.ReadAllData();
		SZO.DisConnect();
	}
}
