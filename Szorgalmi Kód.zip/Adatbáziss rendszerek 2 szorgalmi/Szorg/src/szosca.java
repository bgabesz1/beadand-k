import java.util.Scanner;

public class szosca {

	Scanner scanInput = new Scanner(System.in);
	
	public String ReadData(String s) {
		String data ="";
		System.out.println("\n"+s);
		data=scanInput.nextLine();
		return data;
	}
}
