import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class Szorg1 {
	
		private Statement s = null;
		private Connection c = null;
		private ResultSet RS = null;
		Scanner sc = new Scanner(System.in); 
		
		public void Insert(String kod, String termek,String panasz) {
			String sqlp = "insert into szorg values("+kod+" ,'"+termek+"', '"+panasz+"')";
			try {
				s = c.createStatement();
				s.execute(sqlp);
				SM("insert OK!");
			} catch (SQLException e) {
				SM("JDBC insert: "+e.getMessage());
			}
		}

			public void ReadAllData() {
				String termek="", panasz="", x="\t";
				int kod=0;
				String sqlp= "select kod,termek,panasz from szorg";
				try {
					s = c.createStatement();
					RS = s.executeQuery(sqlp);
					while(RS.next()) {
						kod = RS.getInt("kod");
						termek = RS.getString("termek");
						panasz = RS.getString("panasz");
						 SM(kod+x+termek+x+panasz);
					}
					RS.close();
				} catch (SQLException e) {SM(e.getMessage());}
			}
			
			public void Reg() {
				try {
					Class.forName("org.sqlite.JDBC");
					SM("Sikeres driver regisztr�ci�!");
				}catch (ClassNotFoundException e) {
					SM("hib�s driver regisztr�ci�!");
				}
			}
		   
		   public void Connect() {
				try {
					String url = "jdbc:sqlite:C:/JDBC/szorg.db";
					c = DriverManager.getConnection(url);
					SM("Connection ok!");
				}catch (SQLException e) {
					SM("JDBC Connect:" +e.getMessage());
				}
				
			}
			public void DisConnect() {
				try {
					c.close();
					SM("Disconnection ok!");
				} catch (SQLException e) {SM(e.getMessage());}
			}
			
			public void SM(String msg){
				System.out.println(msg);
			}
			public void Delete() { 
			System.out.println("T�rlend� term�k k�dja: ");
			String kod = sc.next();
			String sqlp = "delete from szorg where kod like '" + kod + "'"; 
			if (c != null) {
				try { s = c.createStatement();
				s.executeUpdate(sqlp);
				s.close();
				System.out.println(kod + " termek t�r�lve\n");
				} catch (Exception ex)
				{System.err.println(ex.getMessage());  
				}
			}
			
			} 
			public void Change() { 
			System.out.println("Modos�tand� term�k k�dj�t �rja be : ");
			String kod = sc.next();
			System.out.println("K�rem a m�dos�tand� term�k panasz�t : ");
			String panasz= sc.next();
			String sqlp = "Update szorg set panasz='" + panasz + "'"  + " where kod like '" + kod + "'"; 
			if (c != null) {
				try { s = c.createStatement();
				s.executeUpdate(sqlp);
				s.close();
				System.out.println(kod + " term�k m�d�s�tva lett\n");
				} catch (Exception ex)
				{System.err.println(ex.getMessage());  
				}
			}
			}
			
}
